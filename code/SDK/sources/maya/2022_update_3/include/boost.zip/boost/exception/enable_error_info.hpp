//Copyright (c) 2006-2009 Emil Dotchevski and Reverge Studios, Inc.

//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef UUID_A0F7404AF7CF11E6908227DD14915323
#define UUID_A0F7404AF7CF11E6908227DD14915323

#include <boost/exception/exception.hpp>

#endif
